# Madabina CLI

**Une interface en ligne de commande native, écrite en Go, pour l’écosystème Madabina.**

> **État du projet :** aperçu préliminaire, conçu pour fonctionner hors ligne. Aucun binaire public ni fiche dans un gestionnaire de paquets n’est disponible pour le moment. Madabina CLI est un logiciel propriétaire; sa licence autorise uniquement la redistribution des binaires originaux non modifiés.

Madabina CLI propose l’affichage de la version, un diagnostic local, un tableau de bord interactif dans le terminal et une console web limitée à la boucle locale. Les diagnostics fonctionnent hors ligne; les pages marchandes de la console nécessitent un compte Madabina et un accès réseau.

## Commandes

| Commande | Description |
| --- | --- |
| `madabina --help` | Afficher l’aide |
| `madabina --version`, `madabina -v`, `madabina -V` | Afficher la version installée |
| `madabina version` | Afficher la version installée |
| `madabina doctor` | Afficher le système et l’architecture locaux |
| `madabina ui` | Ouvrir le tableau de bord interactif |
| `madabina web` | Ouvrir la console locale sur `http://127.0.0.1:7410` |
| `madabina web --desktop` | Démarrer la console avec le protocole de lancement de l’application desktop |
| `madabina` | Ouvrir le tableau de bord dans un terminal interactif, sinon afficher l’aide |

La commande `doctor` et les diagnostics du CLI restent locaux. La console web se connecte via `https://madabina.com/api/v1`, puis donne accès aux statistiques, produits et commandes de la boutique ainsi qu’aux fiches clients en lecture seule. Les jetons de session restent en mémoire et ne sont pas enregistrés sur disque. Utilisez `madabina web --port 8080` pour choisir un autre port. Le serveur écoute uniquement sur `127.0.0.1`, n’est pas accessible depuis les autres appareils du réseau et n’exécute aucune commande shell. Les commandes de gestion des magasins, des agents et de Madabina OS ne sont pas implémentées.

L’application Madabina Desktop, installée séparément du CLI, lance `madabina web --desktop`. Le protocole v1 écrit une ligne JSONL `ready` sur stdout uniquement après l’ouverture du port; elle contient l’URL loopback réellement liée et la version du CLI. À sa fermeture, l’application envoie une commande JSONL `shutdown` versionnée sur stdin; la fermeture de stdin arrête aussi le serveur et révoque les sessions en mémoire. Un conflit de port provoque une sortie sans annonce de disponibilité. Le comportement normal de `madabina web` reste inchangé.

## Installation

Lorsqu’une version sera disponible, téléchargez le binaire correspondant à votre système et à votre architecture depuis les [releases Madabina CLI](https://github.com/madabina-com/madabina-cli/releases), puis vérifiez son checksum SHA-256 et suivez les instructions ci-dessous. La licence n’autorise pas la redistribution ou la modification du code source ni la création de binaires dérivés. Elle permet la redistribution gratuite des binaires originaux non modifiés, avec la licence et les mentions requises; la revente exige une autorisation écrite distincte.

## Windows

Lorsqu’une version sera disponible, téléchargez depuis les [releases Madabina CLI](https://github.com/madabina-com/madabina-cli/releases) l’archive ZIP Windows correspondant à votre architecture, vérifiez son SHA-256 avec `checksums.txt`, extrayez `madabina.exe` dans un dossier appartenant à l’utilisateur et ajoutez ce dossier au `PATH`. Aucun binaire public n’est encore disponible.

## Linux

Lorsqu’une version sera disponible, téléchargez l’archive Linux correspondant à votre architecture depuis les [releases Madabina CLI](https://github.com/madabina-com/madabina-cli/releases). L’installateur vérifié accepte la version, l’URL officielle de téléchargement et un dossier d’installation facultatif :

```sh
./scripts/install.sh vX.Y.Z "$MADABINA_RELEASE_BASE_URL" "$HOME/.local/bin"
```

L’installateur exige HTTPS, vérifie l’archive avec son manifeste SHA-256 avant extraction, rejette les chemins dangereux et fonctionne sans `sudo`. Un checksum récupéré depuis la même version HTTPS protège l’intégrité du transfert, mais n’authentifie pas à lui seul l’éditeur. Vérifiez l’URL publiée par le projet avant toute utilisation. Aucune URL officielle de release n’est encore configurée.

## Android / Termux (ARM64)

Termux est une cible Android distincte. La compilation et l’installation restent **expérimentales tant que le binaire n’a pas été exécuté directement dans Termux**; un binaire Linux ARM64 ou une simple compilation croisée ne suffit pas.

Lorsqu’un binaire Android/Termux ARM64 sera publié, téléchargez-le depuis la page officielle Madabina, vérifiez son checksum et installez-le dans le préfixe Termux. Cette licence n’autorise pas la création ou la redistribution de binaires modifiés :

```sh
install -m 0755 madabina "$PREFIX/bin/madabina"
madabina --version
madabina doctor
```

Consignez les versions de Termux et d’Android ainsi que l’architecture de l’appareil. Les commandes CLI standard sont conçues pour fonctionner sans root ni services système.

## Artefacts de distribution

La configuration de release est en préparation pour Windows, Linux et macOS en AMD64 et ARM64, avec des archives ZIP/TAR.GZ, des paquets Debian et des checksums SHA-256. Android/Termux ARM64 est traité séparément. Les artefacts locaux générés vont dans `public/`, ignoré par Git. Aucun mécanisme du dépôt ne publie automatiquement une version. La redistribution est régie par la licence propriétaire des binaires dans `LICENSE`.

Scoop, WinGet, Homebrew et APT restent des canaux futurs qui ne sont pas configurés.

## Sécurité et préparation à la publication

Avant toute publication, vérifier les licences du projet et de ses dépendances, rechercher les secrets dans le code et l’historique Git, examiner les vulnérabilités des dépendances, lancer les tests et l’analyse statique, inspecter les paquets et archives, vérifier les checksums et auditer l’installateur. La licence propriétaire autorise uniquement la redistribution des binaires originaux non modifiés; elle n’accorde pas le droit de redistribuer le code source ou des binaires modifiés. Cet aperçu n’est pas une version signée.

## Langues

- [English](README.md)
- [العربية](README.ar.md)
