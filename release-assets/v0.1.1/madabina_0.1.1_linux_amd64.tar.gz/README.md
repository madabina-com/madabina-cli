# Madabina CLI

**A native Go command-line interface for the Madabina ecosystem.**

> **Status:** v0.1.0 is available from GitHub Releases. Madabina CLI is proprietary software; its license permits redistribution of original, unmodified binaries only. WinGet publication is pending community review.

Madabina CLI provides version output, a local environment doctor, an interactive terminal dashboard, and a loopback-only web console. CLI diagnostics work offline; merchant pages in the web console require a Madabina account and network access.

## Commands

| Command | Description |
| --- | --- |
| `madabina --help` | Show command help |
| `madabina --version`, `madabina -v`, `madabina -V` | Print the installed version |
| `madabina version` | Print the installed version |
| `madabina doctor` | Show local OS and architecture details |
| `madabina ui` | Open the interactive terminal dashboard |
| `madabina web` | Open the local web console at `http://127.0.0.1:7410` |
| `madabina web --desktop` | Start the console with the local desktop-launch protocol |
| `madabina` | Open the dashboard in an interactive terminal; otherwise show help |

The `doctor` command and runtime diagnostics are local. The web console signs in through `https://madabina.com/api/v1`, then supports store statistics, products, orders, and read-only customer records. Its session tokens stay in memory and are not saved to disk. Use `madabina web --port 8080` to choose another port. By default, the web server binds only to `127.0.0.1`; to allow devices on the LAN, run `madabina web --host 0.0.0.0` (or `madabina web -host=0.0.0.0`). This exposes the console to the network, so use it only on a trusted network and configure the machine firewall accordingly. The server never executes shell commands. Store, agent, and Madabina OS administration commands are not implemented.

The separately installed Madabina Desktop app starts `madabina web --desktop`. Protocol v1 writes one JSONL `ready` record to stdout only after binding, containing the actual loopback URL and CLI version. The app sends a versioned JSONL `shutdown` command on stdin when closing; stdin EOF also shuts down the server and revokes in-memory sessions. A bind conflict exits without a readiness record. This mode does not change the normal `madabina web` output.

## Install

Download a binary from [Madabina CLI releases](https://github.com/madabina-com/madabina-cli/releases) when a release is available. Use only the binary for your operating system and architecture, verify its SHA-256 checksum, and follow the platform instructions below. The source code is not licensed for redistribution, modification, or building derivative binaries. The license permits free redistribution of original, unmodified binaries with the license and required notices included; resale requires separate written permission.

## Windows

The per-user installer is being prepared for [Madabina CLI v0.1.0](https://github.com/madabina-com/madabina-cli/releases/tag/v0.1.0). Once the two `*_setup.exe` assets and updated `checksums.txt` appear there, the installer will set up Madabina CLI under your local programs directory, add it to your user `PATH`, and register an uninstaller without administrator rights.

To download and verify it from PowerShell with `curl.exe`, choose `x64` or `arm64`:

```powershell
$version = '0.1.0'; $arch = 'amd64' # use 'arm64' for Windows ARM64
$name = "madabina_${version}_windows_${arch}_setup.exe"
$base = "https://github.com/madabina-com/madabina-cli/releases/download/v$version"
$checksums = Join-Path $env:TEMP 'madabina-checksums.txt'; $installer = Join-Path $env:TEMP $name
curl.exe --fail --location --silent --show-error "$base/checksums.txt" --output $checksums; if ($LASTEXITCODE -ne 0) { throw 'Checksum download failed' }
curl.exe --fail --location --silent --show-error "$base/$name" --output $installer; if ($LASTEXITCODE -ne 0) { throw 'Installer download failed' }
$expected = ([regex]::Match((Get-Content -Raw $checksums), "(?m)^([0-9a-fA-F]{64})\s+\*?$([regex]::Escape($name))\s*$")).Groups[1].Value
if (-not $expected -or (Get-FileHash $installer -Algorithm SHA256).Hash -ne $expected) { throw 'SHA-256 verification failed' }
Start-Process $installer -Wait
```

The checksum manifest is served with the same HTTPS release; it verifies transfer integrity but does not independently authenticate the publisher. WinGet installation will be documented after Microsoft's community manifest review and merge.

## Linux

When a release is available, download the Linux archive matching your architecture from [Madabina CLI releases](https://github.com/madabina-com/madabina-cli/releases). The verified installer accepts the version, official release download base URL, and optional install directory:

```sh
./scripts/install.sh vX.Y.Z "$MADABINA_RELEASE_BASE_URL" "$HOME/.local/bin"
```

The installer requires HTTPS, verifies the downloaded archive against its SHA-256 manifest before extraction, rejects unsafe archive paths, and installs without `sudo`. A checksum fetched from the same HTTPS release checks transfer integrity; it does not independently authenticate the publisher. Verify the project’s announced release URL before use. No official release URL is configured yet.

## Android / Termux (ARM64)

Termux support is a separate Android target. The build and installation path remains **experimental until the produced binary has been executed directly in Termux**; a Linux ARM64 binary or cross-build alone is not sufficient evidence.

When an Android/Termux ARM64 binary is officially released, download that binary from [Madabina CLI releases](https://github.com/madabina-com/madabina-cli/releases), verify its checksum, and install it into the Termux prefix. Do not build or redistribute modified binaries under this license.

```sh
install -m 0755 madabina "$PREFIX/bin/madabina"
madabina --version
madabina doctor
```

Record the Termux and Android versions and device architecture during validation. Standard CLI commands are designed not to require root or system services.

## Release artifacts

The release configuration is being prepared for Windows, Linux, and macOS on AMD64 and ARM64, with ZIP/TAR.GZ archives, Debian packages, and SHA-256 checksums. Android/Termux ARM64 is handled separately. Generated local artifacts go under the ignored `public/` directory. Nothing in this repository publishes a release automatically. Redistribution is governed by the proprietary binary license in `LICENSE`.

Scoop, WinGet, Homebrew, and APT listings are future channels and are not configured.

## Security and release readiness

Before any public release, review the project and dependency licenses, scan source and Git history for secrets, check dependency vulnerabilities, run tests and static analysis, inspect packages and archives, validate checksums, and review the installer. The proprietary license permits redistribution of original, unmodified binaries only; it does not grant rights to redistribute source code or modified binaries. Do not treat this preview as a signed release.

## Languages

- [Français](README.fr.md)
- [العربية](README.ar.md)
