# Asterisk helper package files

# Asterisk helper package files

This guide applies to the Asterisk administration page shipped with Madabina CLI v0.2.0. It supports Ubuntu/Debian with systemd and a local Asterisk installation; remote SSH and other Linux distributions are not supported.

The Debian package installs the helper binary and `madabina-telephony-helper.service`. The page reports Asterisk presence/version, service state, helper availability, loaded modules, and read-only host diagnostics. Guided forms manage PJSIP, dialplan, queues, voicemail, module loading, and codecs. Service start/stop/restart actions require confirmation. Network, UFW, TLS, and logs remain read-only.

Configuration is written under `/etc/asterisk/madabina-managed/`, included by Asterisk's main configuration, and backed up as `.madabina-backup`. The helper writes files atomically, reloads Asterisk, and restores prior configuration if reload fails. New PJSIP auth sections and voicemail mailboxes require passwords; existing passwords are retained when left blank.

The service runs as root because Asterisk configuration and service controls are privileged. Its Unix socket is mode `0660`, owned by `root:asterisk`; only local users already in the Asterisk group can call the helper. The helper accepts a fixed set of status, configuration, and Asterisk service operations. It does not accept shell commands or file paths from clients. The web telephony API is enabled only for a loopback listener.

The helper requires Ubuntu or Debian with systemd and an installed Asterisk package that provides the `asterisk` group. Install the matching Debian package, add the account running `madabina web` to that group, then start a new login session:

```sh
sudo usermod -aG asterisk "$USER"
sudo systemctl enable --now madabina-telephony-helper.service
```

Without the helper or group membership, the web page remains read-only. Diagnose the components with:

```sh
systemctl status madabina-telephony-helper.service
systemctl status asterisk.service
journalctl -u madabina-telephony-helper.service --no-pager -n 50
```

After adding an account to the group, log out and back in before restarting `madabina web`. Only grant `asterisk` group membership to trusted operators. See [`../../docs/telephony.md`](../../docs/telephony.md) for the full feature guide.
