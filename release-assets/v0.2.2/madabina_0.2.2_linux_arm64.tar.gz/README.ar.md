# Madabina CLI

**واجهة سطر أوامر أصلية مكتوبة بلغة Go لمنظومة Madabina.**

> **حالة المشروع:** الإصدار v0.2.2 متاح في إصدارات GitHub. Madabina CLI برنامج مملوك، ويسمح ترخيصه بإعادة توزيع الملفات الثنائية الأصلية غير المعدلة فقط. ما زال نشر WinGet بانتظار مراجعة المجتمع.

توفر Madabina CLI عرض رقم الإصدار، وفحصاً محلياً للنظام، ولوحة تفاعلية في الطرفية، وواجهة ويب محلية تستمع على الجهاز نفسه. تعمل الفحوصات دون اتصال، بينما تتطلب صفحات التاجر في واجهة الويب حساباً في Madabina واتصالاً بالشبكة.

## الأوامر

| الأمر | الوصف |
| --- | --- |
| `madabina --help` | عرض المساعدة |
| `madabina --version` أو `madabina -v` أو `madabina -V` | عرض الإصدار المثبت |
| `madabina version` | عرض الإصدار المثبت |
| `madabina doctor` | عرض معلومات النظام والمعمارية محلياً |
| `madabina ui` | فتح لوحة الطرفية التفاعلية |
| `madabina web` | فتح واجهة الويب المحلية على `http://127.0.0.1:7410` |
| `madabina web --desktop` | تشغيل الواجهة ببروتوكول بدء تطبيق سطح المكتب |
| `madabina` | فتح اللوحة في طرفية تفاعلية، أو عرض المساعدة عند عدم توفرها |

يبقى أمر `doctor` وتشخيصات CLI محلية. تسجل واجهة الويب الدخول عبر `https://madabina.com/api/v1`، ثم تعرض إحصاءات المتجر والمنتجات والطلبات، مع سجلات العملاء للقراءة فقط. تبقى رموز الجلسة في الذاكرة ولا تُحفظ على القرص. استخدم `madabina web --port 8080` لاختيار منفذ آخر. يستمع الخادم افتراضياً إلى `127.0.0.1` فقط. للسماح للأجهزة على الشبكة المحلية بالوصول، شغّل `madabina web --host 0.0.0.0` (أو `madabina web -host=0.0.0.0`). هذا يجعل الواجهة متاحة عبر الشبكة؛ استخدمه فقط على شبكة موثوقة واضبط جدار الحماية. لا ينفذ الخادم أوامر shell. أوامر إدارة المتاجر والوكلاء ونظام Madabina OS غير منفذة.

تعرض الصفحة `/telephony` حالة أستريسك على أوبونتو/ديبيان مع systemd، وتوفر إعدادات موجّهة وإجراءات مؤكدة للخدمة. لتعديل الإعدادات، ثبّت حزمة Debian التي تتضمن مساعد أستريسك، وأضف مستخدم CLI إلى مجموعة `asterisk`، ثم فعّل `madabina-telephony-helper.service` كما هو موضح في `packaging/systemd/README.md`. بدون المساعد تبقى التعديلات وأوامر الخدمة معطلة. تُعرض الشبكة وجدار الحماية وTLS والسجلات للقراءة فقط. تبقى واجهات الهاتف محصورة في loopback. للوصول عن بُعد، أبقِ CLI على `127.0.0.1` وشغّل `madabina web --trusted-origin https://pbx.example.com` خلف وكيل عكسي TLS يطلب مصادقة المشغّلين. ربط LAN المباشر لا يفعّل واجهات الهاتف؛ يشرح الدليل إعداد الوكيل.

يشغّل تطبيق Madabina Desktop المثبت بشكل منفصل الأمر `madabina web --desktop`. يكتب البروتوكول v1 سطر JSONL واحداً باسم `ready` إلى stdout بعد فتح المنفذ فقط، ويتضمن عنوان loopback الفعلي وإصدار CLI. عند الإغلاق يرسل التطبيق أمراً موثقاً باسم `shutdown` على stdin؛ كما يؤدي إغلاق stdin إلى إيقاف الخادم وإلغاء الجلسات الموجودة في الذاكرة. يؤدي تعارض المنفذ إلى الخروج دون إعلان الجاهزية. لا يتغير السلوك المعتاد للأمر `madabina web`.

## التثبيت

عند توفر إصدار، نزّل الملف الثنائي المطابق لنظام التشغيل والمعمارية من [إصدارات Madabina CLI](https://github.com/madabina-com/madabina-cli/releases)، وتحقق من بصمة SHA-256 ثم اتبع تعليمات النظام أدناه. لا يسمح الترخيص بإعادة توزيع الشيفرة المصدرية أو تعديلها أو إنشاء ملفات ثنائية مشتقة منها. ويسمح بإعادة التوزيع المجاني للملفات الثنائية الأصلية غير المعدلة مع إرفاق الترخيص والإشعارات المطلوبة؛ وتتطلب إعادة البيع إذناً كتابياً منفصلاً.

## Windows

تتوفر مُثبّتات المستخدم لنظام Windows x64 وARM64 في [صفحة الإصدار v0.2.2](https://github.com/madabina-com/madabina-cli/releases/tag/v0.2.2). تثبّت CLI في مجلد برامج المستخدم، وتحدّث `PATH`، وتسجل أداة إلغاء التثبيت دون صلاحيات المدير.

لتنزيله عبر `curl.exe` من PowerShell والتحقق من SHA-256، اختر `amd64` أو `arm64`:

```powershell
$version = '0.2.2'; $arch = 'amd64' # استخدم 'arm64' لأجهزة Windows ARM64
$name = "madabina_${version}_windows_${arch}_setup.exe"
$base = "https://github.com/madabina-com/madabina-cli/releases/download/v$version"
$checksums = Join-Path $env:TEMP 'madabina-checksums.txt'; $installer = Join-Path $env:TEMP $name
curl.exe --fail --location --silent --show-error "$base/checksums.txt" --output $checksums; if ($LASTEXITCODE -ne 0) { throw 'فشل تنزيل ملف checksums' }
curl.exe --fail --location --silent --show-error "$base/$name" --output $installer; if ($LASTEXITCODE -ne 0) { throw 'فشل تنزيل المُثبّت' }
$expected = ([regex]::Match((Get-Content -Raw $checksums), "(?m)^([0-9a-fA-F]{64})\s+\*?$([regex]::Escape($name))\s*$")).Groups[1].Value
if (-not $expected -or (Get-FileHash $installer -Algorithm SHA256).Hash -ne $expected) { throw 'فشل التحقق من SHA-256' }
Start-Process $installer -Wait
```

يُقدَّم ملف checksums عبر إصدار HTTPS نفسه؛ فهو يتحقق من سلامة النقل، لكنه لا يوثّق الناشر بشكل مستقل. ستُضاف تعليمات WinGet بعد مراجعة بيان الحزمة ودمجه من Microsoft.

## Linux

عند توفر إصدار، نزّل أرشيف Linux المطابق لمعمارية جهازك من [إصدارات Madabina CLI](https://github.com/madabina-com/madabina-cli/releases). يقبل برنامج التثبيت الموثق رقم الإصدار وعنوان التنزيل الرسمي ومجلد تثبيت اختياري:

```sh
./scripts/install.sh vX.Y.Z "$MADABINA_RELEASE_BASE_URL" "$HOME/.local/bin"
```

يشترط البرنامج HTTPS، ويتحقق من ملف SHA-256 قبل فك الأرشيف، ويرفض المسارات غير الآمنة، ويثبت دون `sudo`. استخدم عنوان التنزيل بهذا النمط: `https://github.com/madabina-com/madabina-cli/releases/download/vX.Y.Z`. التحقق من بصمة مأخوذة من الإصدار نفسه عبر HTTPS يحمي سلامة النقل، لكنه لا يثبت وحده هوية الناشر.

## Android / Termux (ARM64)

تُعامل Termux كهدف Android مستقل. ما تزال خطوات البناء والتثبيت **تجريبية إلى أن يُشغّل الملف الناتج مباشرة داخل Termux**؛ فملف Linux ARM64 أو نجاح البناء المتقاطع وحده لا يثبت التوافق.

عند نشر ملف Android/Termux ARM64، نزّله من [إصدارات Madabina CLI](https://github.com/madabina-com/madabina-cli/releases)، وتحقق من بصمته ثم ثبّته في مسار Termux. لا يسمح هذا الترخيص بإنشاء ملفات ثنائية معدلة أو إعادة توزيعها:

```sh
install -m 0755 madabina "$PREFIX/bin/madabina"
madabina --version
madabina doctor
```

سجّل إصداري Termux وAndroid ومعمارية الجهاز عند التحقق. صُممت أوامر CLI الاعتيادية للعمل دون صلاحيات الجذر أو خدمات النظام.

## ملفات التوزيع

يجري إعداد تكوين الإصدار لأنظمة Windows وLinux وmacOS بمعماريتي AMD64 وARM64، مع أرشيفات ZIP/TAR.GZ وحزم Debian وبصمات SHA-256. يُبنى Android/Termux ARM64 ويُتحقق منه بشكل مستقل. توضع الملفات الناتجة محلياً في `public/` المستثنى من Git. لا ينشر المستودع أي إصدار تلقائياً. تخضع إعادة التوزيع لترخيص الملفات الثنائية المملوك في `LICENSE`.

تتوفر حزم APT لأنظمة Debian/Ubuntu بمعماريتي AMD64 وARM64. ما زال نشر WinGet بانتظار مراجعة المجتمع؛ أما Scoop وHomebrew فغير مهيأين.

## الأمان والاستعداد للنشر

قبل أي نشر عام، راجع تراخيص المشروع والاعتماديات، وافحص الملفات وسجل Git بحثاً عن الأسرار، وتحقق من ثغرات الاعتماديات، وشغّل الاختبارات والتحليل الساكن، وافحص الأرشيفات والحزم والبصمات، وراجع أمان برنامج التثبيت. يسمح الترخيص المملوك بإعادة توزيع الملفات الثنائية الأصلية غير المعدلة فقط، ولا يمنح حق إعادة توزيع الشيفرة المصدرية أو الملفات الثنائية المعدلة. هذه النسخة الأولية ليست إصداراً موقعاً.

## اللغات

- [English](README.md)
- [Français](README.fr.md)
- [دليل Asterisk](docs/telephony.ar.md) · [English](docs/telephony.md) · [Français](docs/telephony.fr.md)
