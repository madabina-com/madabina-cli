# Asterisk helper package files

The Debian package installs the helper binary and `madabina-telephony-helper.service`.
The service runs as root because Asterisk configuration and service controls are
privileged. Its Unix socket is mode `0660`, owned by `root:asterisk`; only local
users already in the Asterisk group can call the helper. The helper accepts a
fixed set of status, configuration, and Asterisk service operations. It does not
accept shell commands or file paths from clients.

The helper requires Ubuntu or Debian with systemd and an installed Asterisk
package that provides the `asterisk` group. Add the account running `madabina
web` to that group, then start a new login session:

```sh
sudo usermod -aG asterisk "$USER"
sudo systemctl enable --now madabina-telephony-helper.service
```

Without the helper or group membership, the web page remains read-only.
